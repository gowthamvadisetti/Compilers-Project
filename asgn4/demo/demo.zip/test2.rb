if (c)
	if (d)
		d += 1
	else
		d -= 1
	end
end