for i in 1..99
a += 1
end