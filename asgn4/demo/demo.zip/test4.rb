a = foo()
def foo()
	return bar
end