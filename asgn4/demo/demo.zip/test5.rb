if (c & d)
d += 1
elsif (d & e) 
e += 1
else
d -= 1
end