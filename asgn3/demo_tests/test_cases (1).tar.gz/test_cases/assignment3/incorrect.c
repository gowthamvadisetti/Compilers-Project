#include <stdio.h>
int main(){
    int i=6;
    for (;i<= 8 && i 6.67 && i!= 7; i++){
	int 36a;
	int `$#@name;
        if (i>=0);{
            printf("yes\n");
        }
        else 
            printf("no\n");
    }
    return 0;
}
