#!/usr/bin/ruby -w


i = 6

while(true) do
	
	if (i < 8 || i 6.67 || i == 7) 
		break
	end

	36a = 0
	`$#@name = 0

	if i >= 0
		print "yes\n"

	else
		print "no\n"

	end

end



