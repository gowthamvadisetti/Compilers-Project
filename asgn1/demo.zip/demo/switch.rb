#!/usr/bin/ruby -w

wflg, tflg = 0, 0
dflg = 0
c = 'W'


case c
    when 'w'
    
    when 'W'
        wflg = 1

    when 't'

    when 'T'
        tflg = 1       

    when 'W'
        dflg = 1
        

end












