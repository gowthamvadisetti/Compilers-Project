#!/usr/bin/ruby -w

res, i, j, k = 0

for i in 0..9
	for j in 0..9
		for k in 0..9

			res += 1
			
		end
	end
end

puts res

print "#{res}"