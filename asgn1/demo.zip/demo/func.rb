#!/usr/bin/ruby -w

def foo()

   i = 1
   
end

foo()


