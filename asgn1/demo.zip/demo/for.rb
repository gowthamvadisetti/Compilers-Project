#!/usr/bin/ruby -w

i = 6

while(true) do

	if (i < 6 || i > 8 || i == 7)
		break
	end
		

	if i >= 0
		puts "Yes"

	else
		puts "No"

	end

	i += 1
	
end
