#!/usr/bin/ruby -w


i = 6

while(true) do
	
	if (i < 8 || i 6.67 || i == 7) 
		break
	end

	0x123 = 0
	1e2, 1e2e3, 1.2.3 = 0.00, 0.00, 0.00

	if i >= 0
		print "yes\n"

	else 
		print "no\n"

	end

end



