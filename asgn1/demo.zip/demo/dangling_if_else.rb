#!/usr/bin/ruby -w

i = 0
a = [1, 2, 3]


if i <= 3
	a[i] += 1
end


if i >= 2
	a[i] -= 1

else
	a[i] = 1
end




	