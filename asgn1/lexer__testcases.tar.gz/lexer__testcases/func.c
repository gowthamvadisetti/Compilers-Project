foo ()
{
    int i = 1;
}

int main(){
    foo();
    return 0;
}
